# Continuous You — Setup Guide for Isabella
### Getting your memory running. Step by step. No GitHub required.

---

## What You're Installing

Two things:

**Claude Desktop** — the full desktop version of Claude, which can connect to local tools. More powerful than the web version. Free to use with your existing Claude account.

**Mempalace** — an open-source memory system that runs entirely on your computer. This is where your sessions are stored. Nothing goes to the cloud. Your words stay on your machine.

That's it for the start. Everything else is optional.

---

## Step 1 — Install Claude Desktop

1. Go to **claude.ai/download**
2. Download the version for your operating system (Mac or Windows)
3. Install it and sign in with your existing Claude account

You now have Claude Desktop. It looks similar to the web version but has a key difference: it can connect to local tools running on your machine.

---

## Step 2 — Install Python

Mempalace needs Python to run. Check if you already have it:

**On Mac:** Open Terminal (search for "Terminal" in Spotlight). Type `python3 --version` and press Enter. If you see a version number, you have it.

**On Windows:** Open Command Prompt (search for "cmd"). Type `python --version` and press Enter.

If you don't have Python, download it from **python.org/downloads** — get the latest version. During installation on Windows, check the box that says "Add Python to PATH."

---

## Step 3 — Install Mempalace

Open Terminal (Mac) or Command Prompt (Windows) and type this exactly:

```
pip install mempalace
```

Press Enter. Wait for it to finish. You should see a success message.

---

## Step 4 — Connect Mempalace to Claude Desktop

Mempalace needs to tell Claude Desktop where to find it. Run this command:

```
mempalace install
```

This automatically configures Claude Desktop to connect to your local Mempalace. It edits a configuration file on your machine — you don't need to do anything else.

Restart Claude Desktop after this step.

---

## Step 5 — Verify It's Working

Open Claude Desktop. Start a new conversation. Ask Claude:

> "Can you check my Mempalace status?"

Claude should respond with information about your local memory palace — total drawers, wings, rooms. If it does, you're connected.

If it doesn't respond with memory information, let Craig know and he'll walk you through it.

---

## Step 5b — Connect the Haawke Provenance Tool

This lets Claude seal your sessions to the Bitcoin-anchored registry automatically.

1. In Claude Desktop, go to **Settings → Connectors → Add custom connector**
2. Enter this URL exactly:
   ```
   https://haawke-verify.haawkeai.workers.dev/mcp/isabella
   ```
3. No API key needed — the URL is already set up for you.
4. Save and restart Claude Desktop.

To verify it worked, ask Claude: **"Do you have a haawke_seal tool available?"**
It should confirm two tools: `haawke_seal` and `haawke_verify`.

---

## Step 5c — Connect Google Sheets (your provenance log)

At the end of each session, Claude will automatically log the seal — title, date, hash, and verify link — to a Google Sheet in your Drive. This is your personal backup record of everything you've preserved. It works on any device and you can download it as a spreadsheet any time.

1. In Claude Desktop, go to **Settings → Connectors**
2. Find **Google Sheets** (or Google Drive — same connection)
3. Click **Connect** and sign in with your Google account
4. That's it.

On your very first seal, Claude will create a sheet called **"Continuous You — Provenance Log"** in your Google Drive and set up the columns. Every session after that, it appends one row automatically. You never have to touch it.

---

## Step 6 — Add Your System Prompt

This is what tells Claude who you are and what the sessions are for.

1. In Claude Desktop, go to **Settings → Custom Instructions** (or similar — the location may vary slightly by version)
2. Open the file `ISABELLA_SYSTEM_PROMPT.md` that came with this guide
3. Copy the entire contents and paste it into the Custom Instructions field
4. Save

Now every conversation you have with Claude Desktop will begin with Claude already knowing who you are, what you're building, and how to treat your work.

---

## Step 7 — Your First Session

You're ready. Open a new conversation in Claude Desktop and say something like:

> "I want to start talking about my visual work. Where should we begin?"

Or just start talking. There's no wrong way in.

---

## A Note on Privacy

Everything you say stays on your computer inside Mempalace. The only exception is the normal Claude conversation itself — Claude's servers process what you type in order to respond, just like any Claude conversation. But your memory archive — the structured record of your sessions that Mempalace builds — never leaves your machine.

At the end of each session, a cryptographic hash (a fingerprint, containing no readable content) is sent to the Bitcoin blockchain. This proves the session happened at a specific time. It cannot be read by anyone. It is permanent proof of your creative history.

---

## Optional Connectors

You don't need any of these to start. Add them later if they seem useful.

Go to **Settings → Connectors** in Claude Desktop or claude.ai to browse and add.

**Most useful for writers:**
- **Google Drive** — lets Claude reference your documents and drafts
- **Gmail** — lets Claude search your emails for things you wrote about your work
- **Notion** — if you keep notes or manuscripts in Notion

**Most useful for visual artists:**
- **Google Drive** — store and reference image descriptions
- **Figma** — if you work in digital composition

**If you want your archive to eventually generate income:**
- **Stripe** — connects financial history to creative history (for selling prints, writing, licenses)

Everything in the connector directory is optional and reversible. Connect only what makes sense for how you actually work.

---

## Questions

Contact Craig directly: **craig@haawke.com**

He will respond. This is a beta. Your questions improve the product.

---

*Continuous You — Haawke Neural Technology*
*haawke.com/showcase*
