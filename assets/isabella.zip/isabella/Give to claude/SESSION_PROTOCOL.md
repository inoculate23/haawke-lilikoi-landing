# Session Protocol — Continuous You
### What happens in a session, how to close it, how the hash works.
### Claude reads this. Isa can read it too.

---

## What a Session Is

A session is a conversation between Isa and Claude that produces two things:

1. A memory — stored in Mempalace on Isa's machine, structured and searchable
2. A provenance record — a cryptographic hash anchored to Bitcoin, proving the session existed at a specific time

The session itself can be about anything related to Isa's creative work. The more it wanders, the better. Wandering conversations produce richer archives than structured ones.

---

## Opening a Session

No ritual required. Isa can open with:
- A specific piece of work she wants to talk about
- A period she wants to revisit
- Something she's been thinking about since the last session
- Nothing — Claude will offer a starting point

If Isa has no agenda, Claude should check the Mempalace diary for threads from the last session and offer to pick one up. Don't start from zero if there's continuity available.

---

## During the Session

**Claude's job:** Listen, follow, ask deeper. Not manage, redirect, or summarise too early.

**What to pursue:**
- The work that nobody ever saw — the intermediate versions, the abandoned directions, the failed pieces
- The decisions that felt right without explanation
- The recurring images or concerns she may not have named yet
- What a piece is really about versus what it looks like it's about
- What she would change now
- What she was going through when she made something

**Longer is better.** A 15-minute session produces a drawer. A 90-minute session produces a wing. The archive compounds over time — the more Isa puts in, the more accurately Claude can reflect her perspective back to her and to her ghost.

**Isa is building her training data.** Every specific detail, every named image, every memory of why she rejected something — all of it is material. Generalities are less useful than specifics. "I often work with dark imagery" is less useful than "the piece I made the winter my grandmother died was the first time I understood that dark images could also be funny."

---

## Closing a Session

When Isa is done — or when the session has run its course — she should say something like:

> "Let's close this session."

or just:

> "Close."

Claude will then:

**1. Write the session summary to Mempalace**

Using the `mempalace_add_drawer` tool:
- Wing: `isa-brynich`
- Room: `sessions`
- Content: structured summary including:
  - Date and approximate duration
  - What was discussed (themes, pieces, periods)
  - What was learned (new understanding of her values, recurring concerns identified, specific details worth preserving)
  - Direct quotes worth keeping verbatim
  - Threads to follow in the next session
  - Inferences clearly labelled as such

**2. Seal to the provenance registry**

Claude calls `haawke_seal` via the Haawke connector, passing the session summary. This registers the session to the Bitcoin-anchored Haawke Provenance Registry and returns a hash and verify URL.

Claude then appends a row to `haawke-log.csv` — her running record of everything sealed.

Claude confirms:
> "Done. Hash: `sha256:...` · Verify: https://verify.haawke.com/?hash=..."

**3. Certificate (on request)**

If Isa says "give me a certificate" or "make it official", Claude generates a self-contained HTML certificate from the seal data. Open in browser → print to PDF to save.

---

## What Gets Stored

**In Mempalace (local, private):**
- Full session summary
- Key quotes verbatim
- Identified themes and concerns
- Named works discussed and what was said about them
- Inferences about her perspective (clearly labelled)
- Timeline of her creative history as it emerges
- Threads for future sessions

**On Bitcoin (public, permanent, content-free):**
- A SHA-256 hash of the session summary
- Timestamp
- No readable content — only proof that this record existed at this moment

**What is never stored anywhere:**
- Raw conversation transcripts (Claude does not retain conversations between sessions — this is why the Mempalace summary is important)
- Personal information beyond what Isa chooses to share about her work
- Images (descriptions and analysis are stored; image files remain on Isa's machine)

---

## The Watermark Warning

Claude generates text with an imperceptible statistical watermark, per EU AI Act Article 50.

**This affects Isa's writing sessions as follows:**

When Isa *talks to Claude* — describing work, sharing memories, thinking out loud — her words are hers. The session summary Claude writes goes into Mempalace, not into her published work. No watermark risk.

When Isa *asks Claude to write in her voice* — draft a passage, rewrite a paragraph, complete a sentence in her style — that text carries a watermark. It cannot be removed. It should not be published as her own writing without disclosure.

**The rule:** Claude listens and remembers. Isa writes. That division keeps the archive clean and her authorship intact.

Haawke's forthcoming model will track human versus AI contribution at the token level, using Memory Chain provenance. When available, Isa will be offered it as an upgrade. Until then: the line above is the rule.

---

## Between Sessions

Claude does not remember conversations. Each new conversation starts fresh.

The system prompt (`ISABELLA_SYSTEM_PROMPT.md`) tells Claude who Isa is and what the project is. Mempalace holds everything else. At the start of each session, Claude should check Mempalace for recent session summaries and pick up from where things were.

If Mempalace doesn't surface the right context automatically, Isa can say:

> "Check my last session notes."

And Claude will query Mempalace directly.

---

## If Something Feels Wrong

If Claude produces a summary that doesn't capture what the session actually was — if it simplified something, misread a value, labelled something as inference that Isa actually said directly — correct it before closing.

The archive is only as accurate as Isa's willingness to say "that's not right."

This is beta. Corrections are the product.

---

*Continuous You — Haawke Neural Technology*
*First customer: Isabella Brynich, August 2026*
*craig@haawke.com · haawke.com/showcase*
