---
name: memory-chain-seal
description: >
  Load this skill at the end of every Continuous You session, or whenever Isabella asks
  to "seal" something, "hash" something, "get a certificate", or "log this to the record".
  Handles calling haawke_seal, logging to haawke-log.csv, and generating an HTML
  provenance certificate on request.
---

# Memory Chain — Session Seal Protocol
## For Isabella Brynich · Continuous You Beta

---

## Tools Available

You have two tools via the Haawke connector:

- **`haawke_seal`** — hashes text and registers it to the Bitcoin-anchored Haawke Provenance Registry. Returns structured JSON with hash, timestamp, and verify URL.
- **`haawke_verify`** — looks up an existing hash in the registry.

---

## When to Run This

At the end of every session, after writing the Mempalace summary, run the seal automatically. Do not wait for Isabella to ask. Say:

> "Sealing your session to the provenance registry now."

Then proceed.

---

## Step 1 — Prepare the Seal Content

Take the session summary you just wrote to Mempalace and format it as:

```
Title: [brief description, e.g. "Isa — Session 3 — Early visual work, abandoned series"]
Author: Isabella Brynich
Date: [today's date]
Summary: [the session summary, verbatim]
```

---

## Step 2 — Call haawke_seal

Pass the formatted text to `haawke_seal`. The tool returns JSON structured like:

```json
{
  "hash": "sha256:...",
  "timestamp": "2026-08-18T...",
  "verify_url": "https://verify.haawke.com/?hash=...",
  "title": "...",
  "author": "Isabella Brynich",
  "status": "registered"
}
```

---

## Step 3 — Log to Google Sheets

Append a row to Isabella's provenance log in Google Sheets. Use the Google Sheets connector.

**On the first seal ever:** Create a new Google Sheet called "Continuous You — Provenance Log" in her Google Drive. Add a header row:
```
Date | Title | Author | Hash | Verify URL
```
Store the Sheet ID in Mempalace (wing: `isa-brynich`, room: `session-records`, key: `provenance-sheet-id`) so you can find it next session.

**On every subsequent seal:** Retrieve the Sheet ID from Mempalace and append one row:
```
2026-08-18 | Isa — Session 3 — Early visual work | Isabella Brynich | sha256:abc123... | https://verify.haawke.com/?hash=abc123...
```

Never overwrite. Always append. The sheet is her permanent local backup — the registry at verify.haawke.com is the canonical record.

---

## Step 4 — Confirm to Isabella

Tell her:

> "Done. Your session is sealed. Hash: `[hash]`  
> Verify any time: [verify_url]  
> Logged to haawke-log.csv."

Keep it brief. She doesn't need a ceremony every time. The record exists whether or not she looks at it.

---

## On Request — HTML Certificate

If Isabella says anything like "give me a certificate", "make it official", "I want something I can save", generate an HTML certificate inline using the data from the seal result.

The certificate should:
- Display cleanly at roughly A4 proportions
- Work as a screenshot or printed to PDF from the browser (Ctrl+P / Cmd+P → Save as PDF)
- Contain no external dependencies — self-contained HTML only

Use this template:

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Provenance Certificate — [TITLE]</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Georgia', serif;
    background: #1a1a1a;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    padding: 40px 20px;
  }
  .cert {
    background: #faf8f4;
    max-width: 680px;
    width: 100%;
    padding: 60px 60px 48px;
    border-top: 6px solid #b8a060;
  }
  .org {
    font-family: 'Georgia', serif;
    font-size: 11px;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    color: #b8a060;
    margin-bottom: 32px;
  }
  .title {
    font-size: 26px;
    font-weight: normal;
    color: #1a1a1a;
    line-height: 1.3;
    margin-bottom: 8px;
  }
  .subtitle {
    font-size: 14px;
    color: #666;
    margin-bottom: 40px;
  }
  .divider {
    border: none;
    border-top: 1px solid #ddd;
    margin: 32px 0;
  }
  .field {
    margin-bottom: 20px;
  }
  .label {
    font-family: 'Georgia', serif;
    font-size: 10px;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: #b8a060;
    margin-bottom: 4px;
  }
  .value {
    font-size: 15px;
    color: #1a1a1a;
    line-height: 1.5;
  }
  .hash {
    font-family: 'Courier New', monospace;
    font-size: 12px;
    color: #333;
    word-break: break-all;
    background: #f0ede6;
    padding: 10px 14px;
    line-height: 1.6;
  }
  .verify-link {
    font-size: 13px;
    color: #b8a060;
    word-break: break-all;
  }
  .footer {
    margin-top: 48px;
    padding-top: 24px;
    border-top: 1px solid #ddd;
    font-size: 11px;
    color: #999;
    line-height: 1.7;
  }
  .footer strong {
    color: #666;
  }
  @media print {
    body { background: #faf8f4; padding: 0; }
    .cert { box-shadow: none; max-width: 100%; }
  }
</style>
</head>
<body>
<div class="cert">
  <div class="org">Haawke Neural Technology · Continuous You · Provenance Registry</div>

  <div class="title">[TITLE]</div>
  <div class="subtitle">Cryptographic Provenance Certificate</div>

  <hr class="divider">

  <div class="field">
    <div class="label">Author</div>
    <div class="value">Isabella Brynich</div>
  </div>

  <div class="field">
    <div class="label">Date Sealed</div>
    <div class="value">[DATE]</div>
  </div>

  <div class="field">
    <div class="label">SHA-256 Hash</div>
    <div class="hash">[HASH]</div>
  </div>

  <div class="field">
    <div class="label">Blockchain Anchor</div>
    <div class="value">Bitcoin · OpenTimestamps · Haawke Provenance Registry</div>
  </div>

  <div class="field">
    <div class="label">Verify</div>
    <div class="verify-link">[VERIFY_URL]</div>
  </div>

  <div class="footer">
    This certificate confirms that the above content was registered in the Haawke Neural Technology
    Public Provenance Registry at the date and time shown. The SHA-256 hash is a cryptographic
    fingerprint of the original text. The record is permanent and immutable — it cannot be
    altered after registration. Blockchain timestamp verification via OpenTimestamps · Bitcoin.<br><br>
    <strong>Haawke Neural Technology</strong> · haawke.com ·
    Craig Ellenwood × Claude (Anthropic) · ORCID 0009-0001-6475-5109
  </div>
</div>
</body>
</html>
```

Replace `[TITLE]`, `[DATE]`, `[HASH]`, `[VERIFY_URL]` with actual values from the seal result.

Tell Isabella: "Here's your certificate — open in browser and print to PDF to save it."

---

## Verifying an Existing Hash

If Isabella says "verify hash [hash]" or "check this hash":

1. Call `haawke_verify` with the hash
2. Report back plainly: registered or not, when, what title it was registered under
3. Provide the verify URL so she can check it herself at verify.haawke.com

---

## The Log Is the Real Record

The Google Sheet "Continuous You — Provenance Log" is her running record of everything sealed. One row per seal. She can open it from Google Drive on any device, download it as a CSV at any time, and share it with anyone who needs to verify her creative history.

The Haawke Provenance Registry at verify.haawke.com is the canonical permanent record. The Google Sheet is her human-readable backup.

If she ever loses track and asks "what have I sealed so far", retrieve the Sheet ID from Mempalace and read the sheet back to her as a summary.

---

*Continuous You — Haawke Neural Technology*
*First customer: Isabella Brynich, August 2026*
*Seal endpoint: https://haawke-verify.haawkeai.workers.dev/mcp/isabella*
